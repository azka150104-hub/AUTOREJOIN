--!strict
-- Letakkan Script ini di ServerScriptService dengan nama: AFKServer

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("AFKConfig"))

-- RemoteEvent dibuat di server, sehingga klien tidak menentukan hadiah atau posisi yang valid.
local remotes = ReplicatedStorage:FindFirstChild("AFKRemotes") or Instance.new("Folder")
remotes.Name = "AFKRemotes"
remotes.Parent = ReplicatedStorage

local requestAFK = remotes:FindFirstChild("RequestAFK") or Instance.new("RemoteEvent")
requestAFK.Name = "RequestAFK"
requestAFK.Parent = remotes

local statusChanged = remotes:FindFirstChild("StatusChanged") or Instance.new("RemoteEvent")
statusChanged.Name = "StatusChanged"
statusChanged.Parent = remotes

local activeAFKPlayers: {[Player]: boolean} = {}
local nextRewardAt: {[Player]: number} = {}
local lastRequestAt: {[Player]: number} = {}
local missingCurrencyWarned: {[Player]: boolean} = {}
local cachedZone: BasePart? = nil

local function getZone(): BasePart?
	if cachedZone and cachedZone:IsDescendantOf(workspace) then
		return cachedZone
	end

	local zone = workspace:FindFirstChild(Config.ZoneName, true)
	if zone and zone:IsA("BasePart") then
		cachedZone = zone
		return zone
	end
	cachedZone = nil
	return nil
end

local function isInsideAFKZone(player: Player): boolean
	if not Config.RequirePlayerInsideZone then
		return true
	end

	local zone = getZone()
	local character = player.Character
	local root = character and character:FindFirstChild("HumanoidRootPart")
	if not zone or not root or not root:IsA("BasePart") then
		return false
	end

	-- Menguji posisi terhadap ukuran dan rotasi Part zona, tanpa mengandalkan event Touched dari klien.
	local localPosition = zone.CFrame:PointToObjectSpace(root.Position)
	local halfSize = zone.Size * 0.5
	return math.abs(localPosition.X) <= halfSize.X
		and math.abs(localPosition.Y) <= halfSize.Y + 3
		and math.abs(localPosition.Z) <= halfSize.Z
end

local function updateOverheadLabel(player: Player)
	local character = player.Character
	local head = character and character:FindFirstChild("Head")
	if not head or not head:IsA("BasePart") then
		return
	end

	local existing = head:FindFirstChild("AFKLabel")
	if player:GetAttribute("IsAFK") ~= true then
		if existing then
			existing:Destroy()
		end
		return
	end

	if existing then
		return
	end

	local billboard = Instance.new("BillboardGui")
	billboard.Name = "AFKLabel"
	billboard.Size = UDim2.fromOffset(130, 30)
	billboard.StudsOffset = Vector3.new(0, 3, 0)
	billboard.AlwaysOnTop = true
	billboard.Parent = head

	local text = Instance.new("TextLabel")
	text.Size = UDim2.fromScale(1, 1)
	text.BackgroundTransparency = 1
	text.Text = Config.AFKLabelText
	text.TextColor3 = Color3.fromRGB(255, 221, 87)
	text.TextStrokeTransparency = 0.35
	text.TextScaled = true
	text.Font = Enum.Font.GothamBold
	text.Parent = billboard
end

local function setAFK(player: Player, enabled: boolean, message: string?)
	player:SetAttribute("IsAFK", enabled)
	if enabled then
		activeAFKPlayers[player] = true
		nextRewardAt[player] = os.clock() + Config.RewardIntervalSeconds
	else
		activeAFKPlayers[player] = nil
		nextRewardAt[player] = nil
	end
	updateOverheadLabel(player)
	statusChanged:FireClient(player, enabled, message)
end

local function awardReward(player: Player)
	-- Integrasikan ke service ekonomi milik game jika memakai DataStore/profil sendiri.
	-- Contoh bawaan ini hanya mendukung IntValue di player.leaderstats.
	local leaderstats = player:FindFirstChild("leaderstats")
	local currency = leaderstats and leaderstats:FindFirstChild(Config.CurrencyValueName)
	if currency and currency:IsA("IntValue") then
		currency.Value += Config.RewardAmount
		return true
	end

	if not missingCurrencyWarned[player] then
		missingCurrencyWarned[player] = true
		warn(("[AFK] Mata uang '%s' tidak ditemukan untuk %s"):format(Config.CurrencyValueName, player.Name))
	end
	return false
end

requestAFK.OnServerEvent:Connect(function(player: Player, wantsAFK: unknown)
	if typeof(wantsAFK) ~= "boolean" then
		return
	end

	-- Menahan spam RemoteEvent.
	local now = os.clock()
	if now - (lastRequestAt[player] or 0) < 0.5 then
		return
	end
	lastRequestAt[player] = now

	if wantsAFK and not isInsideAFKZone(player) then
		statusChanged:FireClient(player, false, "Masuk ke zona AFK terlebih dahulu.")
		return
	end

	setAFK(player, wantsAFK, wantsAFK and "Mode AFK aktif." or "Mode AFK dimatikan.")
end)

Players.PlayerAdded:Connect(function(player)
	player:SetAttribute("IsAFK", false)

	player.CharacterAdded:Connect(function()
		task.defer(updateOverheadLabel, player)
	end)
end)

Players.PlayerRemoving:Connect(function(player)
	activeAFKPlayers[player] = nil
	nextRewardAt[player] = nil
	lastRequestAt[player] = nil
	missingCurrencyWarned[player] = nil
end)

-- Hanya pemain AFK yang diproses. Tidak ada pencarian Workspace berulang selama zona masih ada.
task.spawn(function()
	while true do
		task.wait(Config.AFKCheckIntervalSeconds)
		local now = os.clock()
		for player in pairs(activeAFKPlayers) do
			if not player:IsDescendantOf(Players) then
				activeAFKPlayers[player] = nil
				nextRewardAt[player] = nil
			elseif not isInsideAFKZone(player) then
				setAFK(player, false, "Mode AFK dihentikan karena kamu keluar dari zona.")
			elseif now >= (nextRewardAt[player] or now) then
				awardReward(player)
				-- Tidak membayar reward tertunggak saat server lag.
				nextRewardAt[player] = now + Config.RewardIntervalSeconds
			end
		end
	end
end)
