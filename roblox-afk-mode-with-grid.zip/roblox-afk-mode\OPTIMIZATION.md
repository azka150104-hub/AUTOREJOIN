# Optimasi untuk game kebun Roblox

Optimasi sudah diterapkan pada sistem AFK: server hanya memeriksa pemain yang AFK, `AFKZone` di-cache, dan jadwal hadiah memakai waktu server sehingga tidak perlu loop setiap detik untuk seluruh pemain.

Pengaturan yang disarankan di Roblox Studio:

1. Untuk map kebun yang besar, aktifkan `Workspace.StreamingEnabled` dan uji apakah tanaman/objek yang jauh tetap muncul sesuai kebutuhan gameplay.
2. Simpan logika pertumbuhan, hadiah, serta uang di `ServerScriptService`; klien cukup menampilkan visual dan UI.
3. Hindari satu Script/`while true do` untuk setiap tanaman. Gunakan satu scheduler server atau sistem batch untuk memperbarui beberapa tanaman sekaligus.
4. Gunakan tag melalui `CollectionService` untuk kelompok tanaman/dekorasi, bukan pencarian `workspace:GetDescendants()` yang berulang.
5. Kurangi `ParticleEmitter`, `PointLight`, `SurfaceGui`, dan part kecil pada area yang padat; gunakan mesh atau tekstur berulang untuk dekorasi.
6. Jalankan **MicroProfiler** dan **Developer Console** saat Play Test untuk mencari script atau asset yang memakai waktu/frame paling besar sebelum mengubah hal lain.

Jangan membuat reward ekonomi di LocalScript. Selain lebih mudah dieksploitasi, hal itu membuat data pemain tidak konsisten di server publik.
