--!strict
-- Letakkan ModuleScript ini di ReplicatedStorage dengan nama: AFKConfig

return {
	-- Buat sebuah Part bernama "AFKZone" di Workspace. Jadikan Anchored dan CanCollide = false.
	ZoneName = "AFKZone",
	RequirePlayerInsideZone = true,

	-- Hadiah diberikan oleh server saja, setiap pemain masih berada dalam mode AFK.
	RewardIntervalSeconds = 60,
	RewardAmount = 10,
	CurrencyValueName = "Coins", -- Contoh: "Sheckles", "Coins", atau "Gems"
	-- Server hanya mengecek pemain yang sedang AFK, sesuai interval ini.
	AFKCheckIntervalSeconds = 5,

	-- Teks yang tampil di atas karakter ketika mode AFK aktif.
	AFKLabelText = "SEDANG AFK",
}
