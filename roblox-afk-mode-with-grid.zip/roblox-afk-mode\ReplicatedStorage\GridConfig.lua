--!strict
-- Letakkan ModuleScript ini di ReplicatedStorage dengan nama: GridConfig

return {
	-- Buat sebuah Part datar bernama "FarmGrid" di Workspace.
	GridPartName = "FarmGrid",
	CellSize = 4,
	CellPadding = 0.15,
	PlotHeight = 0.35,

	-- Batas aman agar pemain tidak dapat menaruh plot dari jarak jauh.
	MaxPlacementDistance = 32,
	MaxPlotsPerPlayer = 50,
	RequestCooldownSeconds = 0.15,

	-- Set 0 jika plot tidak memerlukan biaya.
	PlotCost = 5,
	CurrencyValueName = "Coins",
	ClearPlotsWhenPlayerLeaves = true,
}
