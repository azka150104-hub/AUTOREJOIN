--!strict
-- Letakkan LocalScript ini di StarterPlayer > StarterPlayerScripts dengan nama: AFKClient

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local player = Players.LocalPlayer
local remotes = ReplicatedStorage:WaitForChild("AFKRemotes")
local requestAFK = remotes:WaitForChild("RequestAFK") :: RemoteEvent
local statusChanged = remotes:WaitForChild("StatusChanged") :: RemoteEvent

local gui = Instance.new("ScreenGui")
gui.Name = "AFKGui"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local button = Instance.new("TextButton")
button.Name = "AFKButton"
button.AnchorPoint = Vector2.new(1, 1)
button.Position = UDim2.new(1, -24, 1, -24)
button.Size = UDim2.fromOffset(180, 52)
button.BackgroundColor3 = Color3.fromRGB(53, 117, 70)
button.TextColor3 = Color3.new(1, 1, 1)
button.TextScaled = true
button.Font = Enum.Font.GothamBold
button.Text = "AKTIFKAN AFK"
button.Parent = gui

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 10)
corner.Parent = button

local feedback = Instance.new("TextLabel")
feedback.AnchorPoint = Vector2.new(1, 1)
feedback.Position = UDim2.new(1, -24, 1, -84)
feedback.Size = UDim2.fromOffset(300, 30)
feedback.BackgroundTransparency = 1
feedback.TextColor3 = Color3.fromRGB(255, 255, 255)
feedback.TextStrokeTransparency = 0.45
feedback.TextXAlignment = Enum.TextXAlignment.Right
feedback.TextScaled = true
feedback.Font = Enum.Font.Gotham
feedback.Text = "Kunjungi zona AFK untuk mendapat hadiah."
feedback.Parent = gui

local function updateButton(isAFK: boolean)
	button.Text = isAFK and "KELUAR DARI AFK" or "AKTIFKAN AFK"
	button.BackgroundColor3 = isAFK and Color3.fromRGB(180, 77, 65) or Color3.fromRGB(53, 117, 70)
end

button.Activated:Connect(function()
	requestAFK:FireServer(player:GetAttribute("IsAFK") ~= true)
end)

statusChanged.OnClientEvent:Connect(function(isAFK: boolean, message: string?)
	updateButton(isAFK)
	if message then
		feedback.Text = message
	end
end)

player:GetAttributeChangedSignal("IsAFK"):Connect(function()
	updateButton(player:GetAttribute("IsAFK") == true)
end)

updateButton(player:GetAttribute("IsAFK") == true)
