--!strict
-- Letakkan Script ini di ServerScriptService dengan nama: GridPlacementServer

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")

local Config = require(ReplicatedStorage:WaitForChild("GridConfig"))

local remotes = ReplicatedStorage:FindFirstChild("GridRemotes") or Instance.new("Folder")
remotes.Name = "GridRemotes"
remotes.Parent = ReplicatedStorage

local requestPlace = remotes:FindFirstChild("RequestPlace") or Instance.new("RemoteEvent")
requestPlace.Name = "RequestPlace"
requestPlace.Parent = remotes

local placementStatus = remotes:FindFirstChild("PlacementStatus") or Instance.new("RemoteEvent")
placementStatus.Name = "PlacementStatus"
placementStatus.Parent = remotes

local placedPlots = workspace:FindFirstChild("PlacedPlots") or Instance.new("Folder")
placedPlots.Name = "PlacedPlots"
placedPlots.Parent = workspace

local occupiedCells: {[string]: BasePart} = {}
local plotCount: {[Player]: number} = {}
local lastRequestAt: {[Player]: number} = {}
local cachedGrid: BasePart? = nil

local function getGrid(): BasePart?
	if cachedGrid and cachedGrid:IsDescendantOf(workspace) then
		return cachedGrid
	end

	local grid = workspace:FindFirstChild(Config.GridPartName, true)
	if grid and grid:IsA("BasePart") then
		cachedGrid = grid
		return grid
	end

	cachedGrid = nil
	return nil
end

local function getCellFromWorldPosition(grid: BasePart, position: Vector3): (number?, number?)
	local localPosition = grid.CFrame:PointToObjectSpace(position)
	local halfSize = grid.Size * 0.5
	local x = math.floor((localPosition.X + halfSize.X) / Config.CellSize)
	local z = math.floor((localPosition.Z + halfSize.Z) / Config.CellSize)
	local cellCountX = math.floor(grid.Size.X / Config.CellSize)
	local cellCountZ = math.floor(grid.Size.Z / Config.CellSize)

	if x < 0 or z < 0 or x >= cellCountX or z >= cellCountZ then
		return nil, nil
	end

	return x, z
end

local function getCellCFrame(grid: BasePart, x: number, z: number): CFrame
	local halfSize = grid.Size * 0.5
	local localX = -halfSize.X + (x + 0.5) * Config.CellSize
	local localZ = -halfSize.Z + (z + 0.5) * Config.CellSize
	local localY = halfSize.Y + Config.PlotHeight * 0.5
	return grid.CFrame * CFrame.new(localX, localY, localZ)
end

local function cellKey(x: number, z: number): string
	return (`{x}:{z}`)
end

local function getCurrency(player: Player): IntValue?
	local leaderstats = player:FindFirstChild("leaderstats")
	local value = leaderstats and leaderstats:FindFirstChild(Config.CurrencyValueName)
	if value and value:IsA("IntValue") then
		return value
	end
	return nil
end

local function makePlot(player: Player, grid: BasePart, x: number, z: number): BasePart
	local plot = Instance.new("Part")
	plot.Name = "FarmPlot"
	plot.Anchored = true
	plot.CanCollide = false
	plot.Material = Enum.Material.Ground
	plot.Color = Color3.fromRGB(103, 72, 46)
	plot.Size = Vector3.new(
		math.max(0.1, Config.CellSize - Config.CellPadding),
		Config.PlotHeight,
		math.max(0.1, Config.CellSize - Config.CellPadding)
	)
	plot.CFrame = getCellCFrame(grid, x, z)
	plot:SetAttribute("OwnerUserId", player.UserId)
	plot:SetAttribute("GridX", x)
	plot:SetAttribute("GridZ", z)
	plot.Parent = placedPlots
	return plot
end

-- Memulihkan status okupansi bila script di-restart saat server masih berjalan.
for _, plot in placedPlots:GetChildren() do
	if plot:IsA("BasePart") then
		local x = plot:GetAttribute("GridX")
		local z = plot:GetAttribute("GridZ")
		if typeof(x) == "number" and typeof(z) == "number" then
			occupiedCells[cellKey(x, z)] = plot
		end
	end
end

requestPlace.OnServerEvent:Connect(function(player: Player, requestedPosition: unknown)
	if typeof(requestedPosition) ~= "Vector3" then
		return
	end

	local now = os.clock()
	if now - (lastRequestAt[player] or 0) < Config.RequestCooldownSeconds then
		return
	end
	lastRequestAt[player] = now

	if (plotCount[player] or 0) >= Config.MaxPlotsPerPlayer then
		placementStatus:FireClient(player, false, "Batas plot sudah tercapai.")
		return
	end

	local grid = getGrid()
	local root = player.Character and player.Character:FindFirstChild("HumanoidRootPart")
	if not grid or not root or not root:IsA("BasePart") then
		placementStatus:FireClient(player, false, "Grid atau karakter belum siap.")
		return
	end

	local x, z = getCellFromWorldPosition(grid, requestedPosition)
	if x == nil or z == nil then
		placementStatus:FireClient(player, false, "Pilih kotak di dalam area grid.")
		return
	end

	local targetPosition = getCellCFrame(grid, x, z).Position
	if (root.Position - targetPosition).Magnitude > Config.MaxPlacementDistance then
		placementStatus:FireClient(player, false, "Terlalu jauh dari lokasi penempatan.")
		return
	end

	local key = cellKey(x, z)
	if occupiedCells[key] then
		placementStatus:FireClient(player, false, "Kotak grid ini sudah terisi.")
		return
	end

	local currency: IntValue? = nil
	if Config.PlotCost > 0 then
		currency = getCurrency(player)
		if not currency then
			placementStatus:FireClient(player, false, "Mata uang belum tersedia.")
			return
		end
		if currency.Value < Config.PlotCost then
			placementStatus:FireClient(player, false, "Koin tidak cukup.")
			return
		end
	end

	-- Semua validasi dilakukan sebelum saldo dan instance diubah.
	if currency then
		currency.Value -= Config.PlotCost
	end
	local plot = makePlot(player, grid, x, z)
	occupiedCells[key] = plot
	plotCount[player] = (plotCount[player] or 0) + 1
	placementStatus:FireClient(player, true, "Plot berhasil ditempatkan.")
end)

Players.PlayerAdded:Connect(function(player)
	local existingCount = 0
	for _, plot in placedPlots:GetChildren() do
		if plot:IsA("BasePart") and plot:GetAttribute("OwnerUserId") == player.UserId then
			existingCount += 1
		end
	end
	plotCount[player] = existingCount
end)

Players.PlayerRemoving:Connect(function(player)
	if Config.ClearPlotsWhenPlayerLeaves then
		for _, plot in placedPlots:GetChildren() do
			if plot:IsA("BasePart") and plot:GetAttribute("OwnerUserId") == player.UserId then
				local x = plot:GetAttribute("GridX")
				local z = plot:GetAttribute("GridZ")
				if typeof(x) == "number" and typeof(z) == "number" then
					occupiedCells[cellKey(x, z)] = nil
				end
				plot:Destroy()
			end
		end
	end

	plotCount[player] = nil
	lastRequestAt[player] = nil
end)
