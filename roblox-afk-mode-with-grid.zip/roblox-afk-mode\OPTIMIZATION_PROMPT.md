# Prompt optimasi game Roblox

Salin prompt berikut ke AI coding assistant bersama script atau struktur game Roblox-mu:

```text
Optimalkan game Roblox saya agar lebih ringan di perangkat Android low-end dan PC spesifikasi rendah, tanpa mengubah gameplay, progres pemain, ekonomi, atau keamanan server.

Konteks game: game kebun dengan tanaman, dekorasi, UI, sistem AFK, dan multiplayer.

Lakukan audit dan perbaikan dengan prioritas berikut:
1. Kurangi pekerjaan berulang di ServerScriptService dan LocalScript. Jangan gunakan loop per-frame atau loop per-detik untuk setiap tanaman/pemain jika dapat memakai scheduler terpusat, event, batching, atau interval yang lebih jarang.
2. Jangan melakukan workspace:GetDescendants() atau pencarian objek besar berulang. Cache referensi, gunakan CollectionService untuk tag objek sejenis, dan bersihkan koneksi/event saat objek dihapus.
3. Pastikan ekonomi, reward AFK, DataStore, validasi RemoteEvent, dan logika progres tetap di server. Jangan memindahkan logika sensitif ke klien demi performa.
4. Ringankan sisi klien: kurangi part kecil, particle, trail, PointLight, SurfaceGui, dan BillboardGui yang berlebihan; gunakan objek visual hanya ketika dekat/terlihat bila memungkinkan.
5. Periksa kebocoran memori: koneksi RBXScriptConnection, task.spawn, coroutine, instance, dan tabel cache harus dibersihkan saat Player/Character/objek dihapus.
6. Buat perubahan minimal dan jelaskan untuk setiap perubahan: masalah performa, perubahan yang dibuat, dampak, dan cara menguji di MicroProfiler/Developer Console.
7. Jangan menghapus fitur atau mengubah nama RemoteEvent/API yang sudah digunakan tanpa menyediakan migrasi yang kompatibel.

Berikan hasil sebagai patch Luau yang siap ditempel, lalu sertakan checklist pengujian untuk server dengan banyak pemain dan perangkat Android low-end.
```
