# Mode AFK legal — Roblox Studio

Paket ini membuat mode AFK di dalam game milikmu sendiri. Pemain harus berdiri di zona AFK, lalu menekan tombol untuk mendapat hadiah berkala. Server yang memeriksa posisi dan menambah mata uang, sehingga klien tidak bisa mengirim nominal hadiah sendiri.

## Pemasangan

1. Di `ReplicatedStorage`, buat `ModuleScript` bernama `AFKConfig`, lalu tempel isi `ReplicatedStorage/AFKConfig.lua`.
2. Di `ServerScriptService`, buat `Script` bernama `AFKServer`, lalu tempel isi `ServerScriptService/AFKServer.server.lua`.
3. Di `StarterPlayer > StarterPlayerScripts`, buat `LocalScript` bernama `AFKClient`, lalu tempel isi `StarterPlayer/StarterPlayerScripts/AFKClient.client.lua`.
4. Buat `Part` di `Workspace` bernama `AFKZone`. Perbesar sesuai area AFK, aktifkan `Anchored`, dan set `CanCollide` ke `false` bila pemain harus bisa berdiri di dalamnya.
5. Sesuaikan `CurrencyValueName`, `RewardAmount`, serta `RewardIntervalSeconds` dalam `AFKConfig`.

Panduan pengaturan performa tersedia di `OPTIMIZATION.md`. Prompt audit/perbaikan untuk AI tersedia di `OPTIMIZATION_PROMPT.md`.

## Auto grid / snap grid

Fitur grid legal dibuat untuk menaruh plot kebun pada kotak terdekat secara otomatis.

1. Buat `Part` datar bernama `FarmGrid` di `Workspace`; atur `Anchored = true` dan ukuran yang habis dibagi `CellSize` (default: 4).
2. Di `ReplicatedStorage`, buat `ModuleScript` bernama `GridConfig`, lalu tempel `ReplicatedStorage/GridConfig.lua`.
3. Di `ServerScriptService`, buat `Script` bernama `GridPlacementServer`, lalu tempel `ServerScriptService/GridPlacementServer.server.lua`.
4. Di `StarterPlayer > StarterPlayerScripts`, buat `LocalScript` bernama `GridPlacementClient`, lalu tempel `StarterPlayer/StarterPlayerScripts/GridPlacementClient.client.lua`.

Pemain menyalakan **MODE GRID**, memilih sebuah kotak, lalu server memeriksa jarak, biaya, batas plot, dan apakah kotak tersebut sudah terisi. Default harga plot adalah 5 `Coins`; ubah menjadi `0` di `GridConfig` jika ingin gratis.

## Integrasi mata uang

Contoh bawaan menambah `IntValue` pada `player.leaderstats`, misalnya `leaderstats.Coins`. Bila sistem ekonomi kebunmu memakai DataStore/ProfileService/modul sendiri, ganti isi fungsi `awardReward()` di `AFKServer.server.lua` dengan pemanggilan service ekonomi yang aman di server.

## Catatan

- Sistem ini tidak mengotomatisasi input atau membypass batas idle Roblox.
- Hadiah berhenti otomatis saat pemain keluar dari zona AFK.
- Jangan menyimpan hadiah hanya di LocalScript; pemberian mata uang harus tetap berada di server.
