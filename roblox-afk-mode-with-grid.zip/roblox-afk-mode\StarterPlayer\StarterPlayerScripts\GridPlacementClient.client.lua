--!strict
-- Letakkan LocalScript ini di StarterPlayer > StarterPlayerScripts dengan nama: GridPlacementClient

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")

local player = Players.LocalPlayer
local camera = workspace.CurrentCamera
local Config = require(ReplicatedStorage:WaitForChild("GridConfig"))
local remotes = ReplicatedStorage:WaitForChild("GridRemotes")
local requestPlace = remotes:WaitForChild("RequestPlace") :: RemoteEvent
local placementStatus = remotes:WaitForChild("PlacementStatus") :: RemoteEvent

local placingMode = false
local cachedGrid: BasePart? = nil

local function getGrid(): BasePart?
	if cachedGrid and cachedGrid:IsDescendantOf(workspace) then
		return cachedGrid
	end
	local grid = workspace:FindFirstChild(Config.GridPartName, true)
	if grid and grid:IsA("BasePart") then
		cachedGrid = grid
		return grid
	end
	cachedGrid = nil
	return nil
end

local function getSnappedCellCFrame(grid: BasePart, screenPosition: Vector2): CFrame?
	local ray = camera:ViewportPointToRay(screenPosition.X, screenPosition.Y)
	local normal = grid.CFrame.UpVector
	local denominator = ray.Direction:Dot(normal)
	if math.abs(denominator) < 0.001 then
		return nil
	end

	local distance = (grid.Position - ray.Origin):Dot(normal) / denominator
	if distance < 0 then
		return nil
	end

	local hitPosition = ray.Origin + ray.Direction * distance
	local localPosition = grid.CFrame:PointToObjectSpace(hitPosition)
	local halfSize = grid.Size * 0.5
	local x = math.floor((localPosition.X + halfSize.X) / Config.CellSize)
	local z = math.floor((localPosition.Z + halfSize.Z) / Config.CellSize)
	local countX = math.floor(grid.Size.X / Config.CellSize)
	local countZ = math.floor(grid.Size.Z / Config.CellSize)
	if x < 0 or z < 0 or x >= countX or z >= countZ then
		return nil
	end

	return grid.CFrame * CFrame.new(
		-halfSize.X + (x + 0.5) * Config.CellSize,
		halfSize.Y + Config.PlotHeight * 0.5,
		-halfSize.Z + (z + 0.5) * Config.CellSize
	)
end

local gui = Instance.new("ScreenGui")
gui.Name = "GridPlacementGui"
gui.ResetOnSpawn = false
gui.Parent = player:WaitForChild("PlayerGui")

local button = Instance.new("TextButton")
button.AnchorPoint = Vector2.new(0, 1)
button.Position = UDim2.new(0, 24, 1, -24)
button.Size = UDim2.fromOffset(190, 52)
button.BackgroundColor3 = Color3.fromRGB(73, 104, 179)
button.TextColor3 = Color3.new(1, 1, 1)
button.Text = "MODE GRID: MATI"
button.TextScaled = true
button.Font = Enum.Font.GothamBold
button.Parent = gui

local corner = Instance.new("UICorner")
corner.CornerRadius = UDim.new(0, 10)
corner.Parent = button

local feedback = Instance.new("TextLabel")
feedback.AnchorPoint = Vector2.new(0, 1)
feedback.Position = UDim2.new(0, 24, 1, -84)
feedback.Size = UDim2.fromOffset(340, 30)
feedback.BackgroundTransparency = 1
feedback.TextColor3 = Color3.fromRGB(255, 255, 255)
feedback.TextStrokeTransparency = 0.45
feedback.TextScaled = true
feedback.TextXAlignment = Enum.TextXAlignment.Left
feedback.Font = Enum.Font.Gotham
feedback.Text = "Aktifkan mode lalu sentuh kotak grid."
feedback.Parent = gui

local preview = Instance.new("Part")
preview.Name = "GridPreview"
preview.Anchored = true
preview.CanCollide = false
preview.CanQuery = false
preview.CanTouch = false
preview.Material = Enum.Material.ForceField
preview.Color = Color3.fromRGB(83, 255, 123)
preview.Transparency = 0.45
preview.Size = Vector3.new(
	math.max(0.1, Config.CellSize - Config.CellPadding),
	Config.PlotHeight,
	math.max(0.1, Config.CellSize - Config.CellPadding)
)
preview.Parent = workspace

local function updateButton()
	button.Text = placingMode and "MODE GRID: AKTIF" or "MODE GRID: MATI"
	button.BackgroundColor3 = placingMode and Color3.fromRGB(55, 150, 84) or Color3.fromRGB(73, 104, 179)
	preview.Transparency = placingMode and 0.45 or 1
end

button.Activated:Connect(function()
	placingMode = not placingMode
	updateButton()
end)

placementStatus.OnClientEvent:Connect(function(success: boolean, message: string)
	feedback.Text = message
	if success then
		placingMode = false
		updateButton()
	end
end)

UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed or not placingMode then
		return
	end
	if input.UserInputType ~= Enum.UserInputType.MouseButton1 and input.UserInputType ~= Enum.UserInputType.Touch then
		return
	end

	local grid = getGrid()
	if not grid then
		feedback.Text = "Part FarmGrid belum dibuat di Workspace."
		return
	end

	local screenPosition = Vector2.new(input.Position.X, input.Position.Y)
	local cellCFrame = getSnappedCellCFrame(grid, screenPosition)
	if cellCFrame then
		requestPlace:FireServer(cellCFrame.Position)
	end
end)

RunService.RenderStepped:Connect(function()
	if not placingMode then
		return
	end
	local grid = getGrid()
	if not grid then
		preview.Transparency = 1
		return
	end

	local cellCFrame = getSnappedCellCFrame(grid, UserInputService:GetMouseLocation())
	if cellCFrame then
		preview.CFrame = cellCFrame
		preview.Transparency = 0.45
	else
		preview.Transparency = 1
	end
end)

updateButton()
